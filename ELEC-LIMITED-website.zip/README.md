# ELEC LIMITED website

GitHub-ready static website for ELEC LIMITED.

## Contact
- Phone: 07388 343961
- WhatsApp: +44 7388 343961
- Email: louis@eastleicesterelec.com
- Domain: www.eastleicesterelec.com
- NICEIC Approved
- Domestic, Commercial & Air Conditioning
- 24/7 Emergency Call-Outs

## Upload to GitHub
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, and `script.js` to the root of the repository.
3. Go to Settings > Pages.
4. Choose Deploy from a branch, select `main` and `/ (root)`.
5. Save and wait for GitHub Pages to publish.

## Connect your domain
In GitHub: Repository > Settings > Pages > Custom domain, enter:
`www.eastleicesterelec.com`

Then add the DNS record at your domain registrar. For the `www` hostname, GitHub Pages normally uses a CNAME pointing to your GitHub Pages hostname. Once DNS is configured and GitHub verifies it, enable HTTPS.

Do not change DNS records until you know which company currently manages the domain. If you tell ChatGPT where the domain is registered (e.g. GoDaddy, 123 Reg, IONOS, Cloudflare), it can give you the exact fields to fill in.
